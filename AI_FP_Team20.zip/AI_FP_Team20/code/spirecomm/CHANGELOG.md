## Changelog ##

#### Development ####
* Added card_in_play, turn, and cards_discarded_this_turn from the Communication Mod combat state
* Added monster move history from the Communication Mod combat state

#### v0.6.0 ####
* Fixed "for_transform" field in card select screens
* Added act boss information from Communication Mod 0.6.0
* Added new power fields from Communication Mod 0.7.0
* Added "limbo" cards from Communication Mod 0.7.0

#### v0.5.0 ####
* Added "any_number" to the grid select screen, to maintain compatibility with Communication Mod 0.5.0

#### v0.4.1

* Added setup.py and installation instructions

#### v0.4.0 ####
* Initial public release